
 

<div class="container mt-3">
    <button onclick="document.getElementById('id01').style.display='block'" class='btn w3-red w3-right'>Add User</button>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-6 w3-content">
            
                    <form wire:submit.prevent="insert">
                        <div class="form-group">
                            <label for="">Enter your First Name</label>
                            <input type="text" wire:model='fname' name="fname" id="" class='form-control'>
                            <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class='w3-text-red'><?php echo e($message); ?><p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Enter your Last Name</label>
                            <input type="text" wire:model='lname' name="lname" id="" class='form-control'>
                            <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class='w3-text-red'><?php echo e($message); ?><p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button  type='submit'  class='btn w3-red mt-2 mb-4'>Add user</button>
                    </form>
                </div>
            </div>
        
</div>
<?php /**PATH C:\xampp\htdocs\Cruds\resources\views/livewire/crud/create.blade.php ENDPATH**/ ?>