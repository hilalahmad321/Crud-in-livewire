<?php return array (
  'cruds' => 'App\\Http\\Livewire\\Cruds',
);