
<div class="container">
    <div class="row">
        <div class="col-md-6 w3-content">
            {{-- <div class="w3-modal" id="id02">
                <div class="w3-modal-content p-5 w3-animate-top"> --}}
                    <form wire:submit.prevent="update">
                        <div class="form-group">
                            <label for="">Enter your First Name</label>
                            <input type="text" wire:model='fname' name="fname" id="" class='form-control'>
                            <input type="hidden" wire:model='id' name="fname" id="" class='form-control'>
                            @error('fname')
                                <p class='w3-text-red'>{{$message}}<p>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="">Enter your Last Name</label>
                            <input type="text" wire:model='lname' name="lname" id="" class='form-control'>
                            @error('lname')
                                <p class='w3-text-red'>{{$message}}<p>
                            @enderror
                        </div>

                        <button  type='submit'  class='btn w3-red mt-2 mb-4'>Update user</button>
                    </form>
                </div>
            </div>
        {{-- </div>
    </div> --}}
</div>