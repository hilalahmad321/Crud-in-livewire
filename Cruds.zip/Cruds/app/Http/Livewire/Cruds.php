<?php

namespace App\Http\Livewire;

use App\Models\crud;
use Livewire\Component;

class Cruds extends Component
{
    public $data='Crud in laravel';
    public $fname,$lname,$getdata,$select_id;
    public $updatedata=false;

 
    private function resetfiled(){
        $this->fname=null;
        $this->lname=null;
    }
    public function render()
    {
       $this->getdata= crud::get();
        return view('livewire.cruds');
    }

    public function updated($field){
        $this->validateOnly($field,[
            'fname'=>'required',
            'lname'=>'required'
        ]);
    }

    public function insert(){

        $this->validate([
            'fname'=>'required',
            'lname'=>'required'
        ]);
        crud::create([
            'fname'=>$this->fname,
            'lname'=>$this->lname
        ]);

        $this->resetfiled();
        session()->flash('success','Data Add Successfully');
    }

    public function destroy($id){
        if($id){
            crud::where('id',$id)->delete();
            session()->flash('delete','Delete Successfully');
        }
    }
    
    public function edit($id){
        $crud=crud::find($id);

        // if($crud){
            $this->select_id=$id;
            $this->fname=$crud->fname;
            $this->lname=$crud->lname;
            $this->updatedata=true;
        // }

        // dd($this->fname);
    }

    public function update(){
        $crud=crud::find($this->select_id);
        $crud->update([
            'fname'=>$this->fname,
            'lname'=>$this->lname
        ]);
        $this->updatedata=false;
        $this->resetfiled();
    }
}
