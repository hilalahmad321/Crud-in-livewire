<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/w3.css')); ?>">
    <title>Crud In Livewire</title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cruds')->html();
} elseif ($_instance->childHasBeenRendered('uqW3oWa')) {
    $componentId = $_instance->getRenderedChildComponentId('uqW3oWa');
    $componentTag = $_instance->getRenderedChildComponentTagName('uqW3oWa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uqW3oWa');
} else {
    $response = \Livewire\Livewire::mount('cruds');
    $html = $response->html();
    $_instance->logRenderedChild('uqW3oWa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\Cruds\resources\views/home.blade.php ENDPATH**/ ?>