<div class="container-fluid w3-red p-4">
    <h1 class='w3-center'><?php echo e($data); ?></h1>
</div>
<?php /**PATH C:\xampp\htdocs\Cruds\resources\views/livewire/crud/title.blade.php ENDPATH**/ ?>