<div>
    {{-- The best athlete wants his opponent at his best. --}}
    @include('livewire.crud.title')

    @if ($updatedata==true)
    @include('livewire.crud.update')
    @else
    @include('livewire.crud.create')
    @endif
   
<div class="container">
    @if (Session()->has('success'))

    <div class="container">
        <div class="alert alert-success">
            {{session('success')}}
        </div>

    @endif
    @if (Session()->has('delete'))

    <div class="container">
        <div class="alert alert-danger">
            {{session('delete')}}
        </div>

    @endif

    <table class="w3-table-all">
        <tr>
            <th>Id</th>
            <th>fname</th>
            <th>lname</th>
            <th>update</th>
            <th>delete</th>
        </tr>
        @foreach ($getdata as $item)
        <tr>
            <td>{{$item->id}}</td>
            <td>{{$item->fname}}</td>
            <td>{{$item->lname}}</td>
            <td><button  wire:click='edit({{$item->id}})' class='btn w3-light-blue'>Update</button></td>
            <td><button wire:click='destroy({{$item->id}})' class="btn w3-red">Delete</button></td>
        </tr>
    @endforeach

    </table>
</div>
  
</div>

